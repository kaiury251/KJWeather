const $ = (s) => document.querySelector(s);
const nf = (n, d = 1) => Number(n).toLocaleString('pt-BR', { minimumFractionDigits: d, maximumFractionDigits: d });
const DEFAULT = { name: 'São Paulo', lat: -23.55, lon: -46.63, gps: false };
const RAIN_MIN = 0.1; // mm por hora a partir de onde conta como chuva
const store = {
  get() { try { return JSON.parse(localStorage.getItem('place')); } catch (e) { return null; } },
  set(p) { try { localStorage.setItem('place', JSON.stringify(p)); } catch (e) {} }
};
let place = store.get();
let busy = false;

const CODES = { 0: 'Céu limpo', 1: 'Quase limpo', 2: 'Parcialmente nublado', 3: 'Nublado', 45: 'Neblina', 48: 'Neblina', 51: 'Garoa fraca', 53: 'Garoa', 55: 'Garoa forte',
  61: 'Chuva fraca', 63: 'Chuva', 65: 'Chuva forte', 66: 'Chuva congelante', 67: 'Chuva congelante', 71: 'Neve fraca', 73: 'Neve', 75: 'Neve forte',
  80: 'Pancadas fracas', 81: 'Pancadas de chuva', 82: 'Pancadas fortes', 95: 'Trovoadas', 96: 'Trovoadas com granizo', 99: 'Trovoadas com granizo' };
const DIRS = ['Norte', 'Nordeste', 'Leste', 'Sudeste', 'Sul', 'Sudoeste', 'Oeste', 'Noroeste'];

const hh = (iso) => parseInt(iso.slice(11, 13), 10);
const pad = (n) => String(n).padStart(2, '0');
function clock(ms, off) { if (ms == null) return '--:--'; const d = new Date(ms + off * 1000); return pad(d.getUTCHours()) + ':' + pad(d.getUTCMinutes()); }

function geo() {
  return new Promise((ok, no) => {
    if (!navigator.geolocation) return no();
    navigator.geolocation.getCurrentPosition((p) => ok({ lat: p.coords.latitude, lon: p.coords.longitude }), no, { timeout: 9000, maximumAge: 600000 });
  });
}
async function cityName(lat, lon) {
  try {
    const r = await fetch(`https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${lat}&longitude=${lon}&localityLanguage=pt`);
    const j = await r.json();
    return j.city || j.locality || j.principalSubdivision || 'Minha localização';
  } catch (e) { return 'Minha localização'; }
}

async function refresh(askGps) {
  if (busy) return; busy = true;
  $('#status').textContent = 'Atualizando…';
  try {
    if (!place) place = DEFAULT;
    if (place.gps || askGps) {
      try { const p = await geo(); place = { name: await cityName(p.lat, p.lon), lat: p.lat, lon: p.lon, gps: true }; store.set(place); }
      catch (e) { /* mantém último local */ }
    }
    $('#city').textContent = place.name + ' ▾';
    const u = `https://api.open-meteo.com/v1/forecast?latitude=${place.lat}&longitude=${place.lon}&timezone=auto&forecast_days=3&wind_speed_unit=kmh&precipitation_unit=mm`
      + `&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m,wind_gusts_10m,wind_direction_10m,precipitation`
      + `&hourly=precipitation,precipitation_probability,wind_speed_10m,wind_gusts_10m`
      + `&daily=sunrise,sunset,temperature_2m_max,temperature_2m_min`;
    const r = await fetch(u); if (!r.ok) throw new Error('http ' + r.status);
    render(await r.json());
    $('#status').textContent = 'Atualizado às ' + new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  } catch (e) {
    $('#hTitle').textContent = 'Sem conexão';
    $('#hSub').textContent = 'Conecte-se à internet e toque em Atualizar.';
    $('#status').textContent = '';
  }
  busy = false;
}
window.refresh = refresh;

function strip(el, items, now) {
  el.innerHTML = items.map((x, i) => `<div class="col${i === 0 ? ' now' : ''}"><span>${i === 0 ? 'Agora' : pad(x.h) + 'h'}</span>
    <div class="bar"><u style="height:${x.pct}%"></u></div><span class="v">${x.v}</span><span class="p">${x.p || ''}</span></div>`).join('');
}

function render(d) {
  const off = d.utc_offset_seconds, c = d.current, H = d.hourly;
  let i0 = H.time.indexOf(c.time.slice(0, 13) + ':00'); if (i0 < 0) i0 = 0;
  const idx = [...Array(24).keys()].map((k) => i0 + k).filter((k) => k < H.time.length);

  // temperatura e condição
  $('#temp').textContent = Math.round(c.temperature_2m) + '°';
  $('#feel').textContent = (CODES[c.weather_code] || '') + ' · máx ' + Math.round(d.daily.temperature_2m_max[0]) + '° mín ' + Math.round(d.daily.temperature_2m_min[0]) + '°';

  // janelas de chuva
  const wins = []; let cur = null;
  idx.forEach((k) => {
    const mm = H.precipitation[k] || 0;
    if (mm >= RAIN_MIN) {
      if (!cur) { cur = { s: k, e: k, mm: 0, pr: 0 }; wins.push(cur); }
      cur.e = k; cur.mm += mm; cur.pr = Math.max(cur.pr, H.precipitation_probability[k] || 0);
    } else cur = null;
  });
  const total = wins.reduce((a, w) => a + w.mm, 0);
  const hr = (k) => pad(hh(H.time[k])) + 'h';
  const hrEnd = (k) => pad((hh(H.time[k]) + 1) % 24) + 'h';
  const w0 = wins[0];
  if (!w0) { $('#hTitle').textContent = 'Não vai chover'; $('#hSub').textContent = 'Nenhuma chuva prevista nas próximas 24 horas.'; }
  else if (w0.s === i0) { $('#hTitle').textContent = 'Chovendo agora'; $('#hSub').textContent = `Até ${hrEnd(w0.e)} · ${nf(w0.mm)} mm nessa janela`; }
  else { $('#hTitle').textContent = 'Chuva às ' + hr(w0.s); const n = w0.s - i0; $('#hSub').textContent = `Daqui a ${n} h · ${nf(total)} mm previstos em 24 h`; }
  $('#windows').innerHTML = wins.length
    ? wins.map((w) => `<span class="chip">${hr(w.s)} – ${hrEnd(w.e)} · ${nf(w.mm)} mm · ${Math.round(w.pr)}%</span>`).join('')
    : '<span class="chip dry">Seco nas próximas 24 h</span>';

  // faixa de chuva
  const maxMm = Math.max(2, ...idx.map((k) => H.precipitation[k] || 0));
  strip($('#rainStrip'), idx.map((k) => {
    const mm = H.precipitation[k] || 0;
    return { h: hh(H.time[k]), pct: mm >= RAIN_MIN ? Math.max(8, (mm / maxMm) * 100) : 0, v: mm >= RAIN_MIN ? nf(mm) : '–', p: Math.round(H.precipitation_probability[k] || 0) + '%' };
  }));

  // vento
  $('#wind').textContent = Math.round(c.wind_speed_10m);
  $('#gust').textContent = 'Rajadas ' + Math.round(c.wind_gusts_10m) + ' km/h';
  $('#wdir').textContent = 'Vem do ' + DIRS[Math.round(c.wind_direction_10m / 45) % 8];
  $('#arrow').style.transform = `rotate(${(c.wind_direction_10m + 180) % 360}deg)`;
  const maxW = Math.max(30, ...idx.map((k) => H.wind_speed_10m[k] || 0));
  strip($('#windStrip'), idx.map((k) => ({ h: hh(H.time[k]), pct: Math.max(6, ((H.wind_speed_10m[k] || 0) / maxW) * 100), v: Math.round(H.wind_speed_10m[k] || 0), p: 'km/h' })));

  // lua
  const [Y, M, D] = c.time.slice(0, 10).split('-').map(Number);
  const dayStart = Date.UTC(Y, M - 1, D) - off * 1000;
  const mt = Moon.times(dayStart, place.lat, place.lon);
  $('#mRise').textContent = clock(mt.rise, off);
  $('#mSet').textContent = clock(mt.set, off);
  const il = Moon.illumination(dayStart + 12 * 36e5), p = il.phase;
  const ph = p < .03 || p >= .97 ? ['🌑', 'Lua nova'] : p < .22 ? ['🌒', 'Lua crescente'] : p < .28 ? ['🌓', 'Quarto crescente'] : p < .47 ? ['🌔', 'Crescente gibosa']
    : p < .53 ? ['🌕', 'Lua cheia'] : p < .72 ? ['🌖', 'Minguante gibosa'] : p < .78 ? ['🌗', 'Quarto minguante'] : ['🌘', 'Lua minguante'];
  $('#mIcon').textContent = ph[0]; $('#mName').textContent = ph[1]; $('#mIllum').textContent = Math.round(il.fraction * 100) + '% iluminada';
  $('#sun').textContent = `Sol: nasce ${d.daily.sunrise[0].slice(11, 16)} · põe ${d.daily.sunset[0].slice(11, 16)}`;
}

// escolha de cidade
const sheet = $('#sheet');
$('#city').onclick = () => { sheet.classList.add('on'); $('#q').focus(); };
$('#close').onclick = () => sheet.classList.remove('on');
$('#reload').onclick = () => refresh(false);
$('#gps').onclick = () => { sheet.classList.remove('on'); busy = false; refresh(true); };
let tm;
$('#q').oninput = (e) => {
  clearTimeout(tm); const v = e.target.value.trim();
  if (v.length < 2) { $('#res').innerHTML = ''; return; }
  tm = setTimeout(async () => {
    try {
      const j = await (await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(v)}&count=6&language=pt`)).json();
      const list = j.results || [];
      $('#res').innerHTML = list.length ? '' : '<div class="status">Nenhuma cidade encontrada</div>';
      list.forEach((r) => {
        const b = document.createElement('button');
        b.textContent = [r.name, r.admin1, r.country].filter(Boolean).join(', ');
        b.onclick = () => { place = { name: r.name, lat: r.latitude, lon: r.longitude, gps: false }; store.set(place); sheet.classList.remove('on'); busy = false; refresh(false); };
        $('#res').appendChild(b);
      });
    } catch (err) { $('#res').innerHTML = '<div class="status">Sem conexão</div>'; }
  }, 350);
};

refresh(!place);
