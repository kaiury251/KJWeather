// Posição, fase, nascer e pôr da lua (cálculo local, sem internet)
(function (root) {
  const rad = Math.PI / 180, dayMs = 864e5, J1970 = 2440588, J2000 = 2451545, e = rad * 23.4397;
  const toDays = (ms) => ms / dayMs - 0.5 + J1970 - J2000;
  const ra = (l, b) => Math.atan2(Math.sin(l) * Math.cos(e) - Math.tan(b) * Math.sin(e), Math.cos(l));
  const dec = (l, b) => Math.asin(Math.sin(b) * Math.cos(e) + Math.cos(b) * Math.sin(e) * Math.sin(l));
  const sidereal = (d, lw) => rad * (280.16 + 360.9856235 * d) - lw;

  function moonCoords(d) {
    const L = rad * (218.316 + 13.176396 * d), M = rad * (134.963 + 13.064993 * d), F = rad * (93.272 + 13.22935 * d);
    const l = L + rad * 6.289 * Math.sin(M), b = rad * 5.128 * Math.sin(F);
    return { ra: ra(l, b), dec: dec(l, b), dist: 385001 - 20905 * Math.cos(M) };
  }

  function altitude(ms, lat, lon) {
    const lw = rad * -lon, phi = rad * lat, d = toDays(ms), c = moonCoords(d), H = sidereal(d, lw) - c.ra;
    return Math.asin(Math.sin(phi) * Math.sin(c.dec) + Math.cos(phi) * Math.cos(c.dec) * Math.cos(H));
  }

  function illumination(ms) {
    const d = toDays(ms), s = (() => {
      const M = rad * (357.5291 + 0.98560028 * d);
      const C = rad * (1.9148 * Math.sin(M) + 0.02 * Math.sin(2 * M) + 0.0003 * Math.sin(3 * M));
      const L = M + C + rad * 102.9372 + Math.PI;
      return { dec: dec(L, 0), ra: ra(L, 0) };
    })();
    const m = moonCoords(d), sdist = 149598000;
    const phi = Math.acos(Math.sin(s.dec) * Math.sin(m.dec) + Math.cos(s.dec) * Math.cos(m.dec) * Math.cos(s.ra - m.ra));
    const inc = Math.atan2(sdist * Math.sin(phi), m.dist - sdist * Math.cos(phi));
    const angle = Math.atan2(Math.cos(s.dec) * Math.sin(s.ra - m.ra),
      Math.sin(s.dec) * Math.cos(m.dec) - Math.cos(s.dec) * Math.sin(m.dec) * Math.cos(s.ra - m.ra));
    return { fraction: (1 + Math.cos(inc)) / 2, phase: 0.5 + (0.5 * inc * (angle < 0 ? -1 : 1)) / Math.PI };
  }

  // dayStart = meia-noite local em ms UTC. Retorna { rise, set } em ms UTC (ou null).
  function times(dayStart, lat, lon) {
    const hc = 0.133 * rad, step = 6e5;
    let rise = null, set = null, prev = altitude(dayStart, lat, lon) - hc;
    for (let t = dayStart + step; t <= dayStart + dayMs; t += step) {
      const cur = altitude(t, lat, lon) - hc;
      const x = prev === cur ? 0 : -prev / (cur - prev);
      if (prev < 0 && cur >= 0 && rise === null) rise = t - step + x * step;
      if (prev >= 0 && cur < 0 && set === null) set = t - step + x * step;
      prev = cur;
    }
    return { rise, set };
  }

  root.Moon = { illumination, times, altitude };
  if (typeof module !== 'undefined') module.exports = root.Moon;
})(typeof window !== 'undefined' ? window : globalThis);
