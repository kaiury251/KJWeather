App Clima (liquid glass, destaque verde #008441)
- Projeto Android (Kotlin + WebView). Interface em app/src/main/assets (index.html, style.css, app.js, moon.js).
- Dados: Open-Meteo (sem chave). Lua: cálculo local.
- Compilar: gradle assembleDebug (Gradle 8.9, JDK 17).
- Para ver no navegador, abra app/src/main/assets/index.html.
